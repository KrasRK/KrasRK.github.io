﻿    /*
    ** Watch_Face_Editor tool
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_sun_high_text_img = ''
        let normal_sun_low_text_img = ''
        let normal_system_clock_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_temperature_current_text_img = ''
        let normal_date_img_date_week_img = ''
        let normal_date_img_date_month_img = ''
        let normal_date_img_date_day = ''
        let normal_digital_clock_img_time = ''
        let normal_digital_clock_hour_separator_img = ''
        let normal_analog_clock_time_pointer_second = ''
        let idle_digital_clock_img_time = ''
        let idle_digital_clock_hour_separator_img = ''
        let normal_battery_jumpable_img_click = ''
        let normal_altimeter_jumpable_img_click = ''
        let normal_stopwatch_jumpable_img_click = ''
        let normal_countdown_jumpable_img_click = ''
        let normal_alarm_jumpable_img_click = ''
        let normal_temperature_jumpable_img_click = ''


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 480,
              h: 480,
              src: 'bg_00.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_high_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 119,
              y: 143,
              font_array: ["v_00.png","v_01.png","v_02.png","v_03.png","v_04.png","v_05.png","v_06.png","v_07.png","v_08.png","v_09.png"],
              padding: false,
              h_space: 3,
              dot_image: 'vx_00.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_RISE,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_sun_low_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 284,
              y: 143,
              font_array: ["v_00.png","v_01.png","v_02.png","v_03.png","v_04.png","v_05.png","v_06.png","v_07.png","v_08.png","v_09.png"],
              padding: false,
              h_space: 3,
              dot_image: 'vx_00.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.SUN_SET,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_system_clock_img = hmUI.createWidget(hmUI.widget.IMG_STATUS, {
              x: 59,
              y: 182,
              src: 'al_00.png',
              type: hmUI.system_status.CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 284,
              y: 86,
              image_array: ["bt_00.png","bt_01.png","bt_02.png","bt_03.png","bt_04.png","bt_05.png","bt_06.png","bt_07.png"],
              image_length: 8,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_current_text_img = hmUI.createWidget(hmUI.widget.TEXT_IMG, {
              x: 179,
              y: 87,
              font_array: ["sn_0.png","sn_1.png","sn_2.png","sn_3.png","sn_4.png","sn_5.png","sn_6.png","sn_7.png","sn_8.png","sn_9.png"],
              padding: false,
              h_space: 7,
              negative_image: 'w_99.png',
              invalid_image: 'w_99.png',
              align_h: hmUI.align.CENTER_H,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_week_img = hmUI.createWidget(hmUI.widget.IMG_WEEK, {
              x: 124,
              y: 333,
              week_en: ["d_01.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png"],
              week_tc: ["d_01.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png"],
              week_sc: ["d_01.png","d_2.png","d_3.png","d_4.png","d_5.png","d_6.png","d_7.png"],
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 290,
              month_startY: 333,
              month_sc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_tc_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_en_array: ["m_1.png","m_2.png","m_3.png","m_4.png","m_5.png","m_6.png","m_7.png","m_8.png","m_9.png","m_10.png","m_11.png","m_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_date_img_date_day = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              day_startX: 212,
              day_startY: 321,
              day_sc_array: ["sn_0.png","sn_1.png","sn_2.png","sn_3.png","sn_4.png","sn_5.png","sn_6.png","sn_7.png","sn_8.png","sn_9.png"],
              day_tc_array: ["sn_0.png","sn_1.png","sn_2.png","sn_3.png","sn_4.png","sn_5.png","sn_6.png","sn_7.png","sn_8.png","sn_9.png"],
              day_en_array: ["sn_0.png","sn_1.png","sn_2.png","sn_3.png","sn_4.png","sn_5.png","sn_6.png","sn_7.png","sn_8.png","sn_9.png"],
              day_zero: 1,
              day_space: 5,
              day_align: hmUI.align.CENTER_H,
              day_is_character: false,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 116,
              hour_startY: 182,
              hour_array: ["bn_0.png","bn_1.png","bn_2.png","bn_3.png","bn_4.png","bn_5.png","bn_6.png","bn_7.png","bn_8.png","bn_9.png"],
              hour_zero: 1,
              hour_space: 12,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 255,
              minute_startY: 182,
              minute_array: ["bn_0.png","bn_1.png","bn_2.png","bn_3.png","bn_4.png","bn_5.png","bn_6.png","bn_7.png","bn_8.png","bn_9.png"],
              minute_zero: 1,
              minute_space: 12,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 234,
              y: 212,
              src: 'bn_10.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_analog_clock_time_pointer_second = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
              second_path: 'second1.png',
              second_centerX: 240,
              second_centerY: 240,
              second_posX: 21,
              second_posY: 193,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


            console.log('Watch_Face.ScreenAOD');

            idle_digital_clock_img_time = hmUI.createWidget(hmUI.widget.IMG_TIME, {
              hour_startX: 58,
              hour_startY: 169,
              hour_array: ["aod_00.png","aod_01.png","aod_02.png","aod_03.png","aod_04.png","aod_5.png","aod_06.png","aod_07.png","aod_08.png","aod_09.png"],
              hour_zero: 1,
              hour_space: 7,
              hour_angle: 0,
              hour_align: hmUI.align.CENTER_H,

              minute_startX: 269,
              minute_startY: 169,
              minute_array: ["aod_00.png","aod_01.png","aod_02.png","aod_03.png","aod_04.png","aod_5.png","aod_06.png","aod_07.png","aod_08.png","aod_09.png"],
              minute_zero: 1,
              minute_space: 7,
              minute_angle: 0,
              minute_follow: 0,
              minute_align: hmUI.align.CENTER_H,

              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_digital_clock_hour_separator_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 203,
              y: 170,
              src: 'Aod_xx.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });
            console.log('Watch_Face.Shortcuts');

            normal_battery_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 276,
              y: 79,
              w: 80,
              h: 50,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_altimeter_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 169,
              y: 285,
              w: 107,
              h: 25,
              type: hmUI.data_type.ALTIMETER,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_stopwatch_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 252,
              y: 197,
              w: 105,
              h: 63,
              type: hmUI.data_type.STOP_WATCH,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_countdown_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 394,
              y: 212,
              w: 66,
              h: 50,
              type: hmUI.data_type.COUNT_DOWN,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_alarm_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 115,
              y: 192,
              w: 111,
              h: 63,
              type: hmUI.data_type.ALARM_CLOCK,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_temperature_jumpable_img_click = hmUI.createWidget(hmUI.widget.IMG_CLICK, {
              x: 200,
              y: 79,
              w: 65,
              h: 50,
              type: hmUI.data_type.WEATHER_CURRENT,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });


                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}